Lab4.cu is the version without warm-up, 
Lab4_3.cu is the version with warm-up but I didn't have time to test it on the PACE server 
due to the teacher responding to the warm-up question in the afternoon of the last day and the crowded server. 
Thanks in advance for your understanding and help.